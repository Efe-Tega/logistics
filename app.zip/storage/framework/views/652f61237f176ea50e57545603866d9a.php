
<?php $__env->startSection('admin'); ?>
    <?php
        $trackingNo = mt_rand(1000000000, 9999999999);
    ?>
    <div class="page-content">

        <div class="row">
            <div class="col-12 mx-auto">
                <h6 class="mb-0 text-uppercase">Create Shipment</h6>
                <hr />
                <div class="card border-4 border-top border-primary border-bottom-0 border-start-0 border-end-0">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <div><i class="bx bxs-user me-1 font-22 text-primary"></i>
                            </div>
                            <h5 class="mb-0 text-primary">Shipper's Details</h5>
                        </div>
                        <hr>

                        <form action="<?php echo e(route('store.shipment')); ?>" method="POST" class="row g-3">
                            <?php echo csrf_field(); ?>

                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Full Name</label>
                                <input type="text" name="shipper_fullname" class="form-control" id="inputFirstName"
                                    value="<?php echo e(old('shipper_fullname')); ?>">

                                <?php $__errorArgs = ['shipper_fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputState" class="form-label">Sex</label>
                                <select id="inputState" class="form-select" name="shipper_gender">
                                    <option value="" selected>Choose...</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>

                                <?php $__errorArgs = ['shipper_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputLastName" class="form-label">Phone</label>
                                <input type="text" class="form-control" id="inputLastName" name="shipper_phone"
                                    value="<?php echo e(old('shipper_phone')); ?>">

                                <?php $__errorArgs = ['shipper_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputEmail" class="form-label">Email</label>
                                <input type="email" class="form-control" id="inputEmail" name="shipper_email"
                                    value="<?php echo e(old('shipper_email')); ?>">

                                <?php $__errorArgs = ['shipper_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputLastName" class="form-label">Home Address</label>
                                <input type="text" class="form-control" id="inputLastName" name="shipper_address"
                                    value="<?php echo e(old('shipper_address')); ?>">

                                <?php $__errorArgs = ['shipper_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputCity" class="form-label">State</label>
                                <input type="text" class="form-control" id="inputCity" name="shipper_state"
                                    value="<?php echo e(old('shipper_state')); ?>">

                                <?php $__errorArgs = ['shipper_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputZip" class="form-label">Zip/Postal Code</label>
                                <input type="text" class="form-control" id="inputZip" name="shipper_postal"
                                    value="<?php echo e(old('shipper_postal')); ?>">

                                <?php $__errorArgs = ['shipper_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputZip" class="form-label">Country</label>
                                <input type="text" class="form-control" id="inputZip" name="shipper_country"
                                    value="<?php echo e(old('shipper_country')); ?>">

                                <?php $__errorArgs = ['shipper_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="card-title d-flex align-items-center">
                                <div><i class="bx bxs-user me-1 font-22 text-primary mt-3"></i>
                                </div>
                                <h5 class="mb-0 text-primary mt-3">Receiver's Details</h5>
                            </div>
                            <hr>

                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="inputFirstName" name="receiver_fullname"
                                    value="<?php echo e(old('receiver_fullname')); ?>">

                                <?php $__errorArgs = ['receiver_fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputState" class="form-label">Sex</label>
                                <select id="inputState" class="form-select" name="receiver_gender">
                                    <option value="" selected>Choose...</option>
                                    <option value="male">Male
                                    </option>
                                    <option value="female">Female</option>
                                </select>

                                <?php $__errorArgs = ['receiver_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputLastName" class="form-label">Phone</label>
                                <input type="text" class="form-control" id="inputLastName" name="receiver_phone"
                                    value="<?php echo e(old('receiver_phone')); ?>">

                                <?php $__errorArgs = ['receiver_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputEmail" class="form-label">Email</label>
                                <input type="email" class="form-control" id="inputEmail" name="receiver_email"
                                    value="<?php echo e(old('receiver_email')); ?>">

                                <?php $__errorArgs = ['receiver_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputLastName" class="form-label">Home Address</label>
                                <input type="text" class="form-control" id="inputLastName" name="receiver_address"
                                    value="<?php echo e(old('receiver_address')); ?>">

                                <?php $__errorArgs = ['receiver_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputCity" class="form-label">State</label>
                                <input type="text" class="form-control" id="inputCity" name="receiver_state"
                                    value="<?php echo e(old('receiver_state')); ?>">

                                <?php $__errorArgs = ['receiver_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputZip" class="form-label">Zip/Postal Code</label>
                                <input type="text" class="form-control" id="inputZip" name="receiver_postal"
                                    value="<?php echo e(old('receiver_postal')); ?>">

                                <?php $__errorArgs = ['receiver_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputZip" class="form-label">Country</label>
                                <input type="text" class="form-control" id="inputZip" name="receiver_country"
                                    value="<?php echo e(old('receiver_country')); ?>">

                                <?php $__errorArgs = ['receiver_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            

                            <div class="card-title d-flex align-items-center">
                                <div><i class="bx bxs-user me-1 font-22 text-primary mt-3"></i>
                                </div>
                                <h5 class="mb-0 text-primary mt-3">Shipment Details</h5>
                            </div>
                            <hr>

                            <div class="col-md-12">
                                <label for="inputFirstName" class="form-label">Tracking Number</label>
                                <input type="text" class="form-control" id="inputFirstName" name="tracking_no"
                                    value="<?php echo e($trackingNo); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="inputState" class="form-label">Freight Type</label>
                                <select id="inputState" class="form-select" name="freight_type">
                                    <option value="" selected>Choose...</option>
                                    <option value="air_freight">Air Freight</option>
                                    <option value="see_freight">Sea Freight</option>
                                    <option value="road_freight">Road Freight</option>
                                    <option value="rail_freight">Rail Freight</option>
                                </select>

                                <?php $__errorArgs = ['freight_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Shipment Content</label>
                                <input type="text" class="form-control" id="inputFirstName" name="shipment_content"
                                    value="<?php echo e(old('shipment_content')); ?>">

                                <?php $__errorArgs = ['shipment_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <label for="inputAddress" class="form-label">Brief Description of Shipment</label>
                                <textarea class="form-control" id="inputAddress" placeholder="brief description" rows="3"
                                    name="shipment_desc"><?php echo e(old('shipment_desc')); ?></textarea>

                                <?php $__errorArgs = ['shipment_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Quantity</label>
                                <input type="text" class="form-control" id="inputFirstName" name="shipment_quantity"
                                    value="<?php echo e(old('shipment_quantity')); ?>">

                                <?php $__errorArgs = ['shipment_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Weight (eg 2kg)</label>
                                <input type="text" class="form-control" id="inputFirstName" name="shipment_weight"
                                    value="<?php echo e(old('shipment_weight')); ?>">

                                <?php $__errorArgs = ['shipment_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputState" class="form-label">Shipment Status</label>
                                <select id="inputState" class="form-select" name="shipment_status">

                                    <option value="" selected>Choose...</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Processing">Processing</option>
                                    <option value="In Transit">In Transit</option>
                                    <option value="Delivered">Delivered</option>
                                    <option value="On Hold">On Hold</option>
                                </select>

                                <?php $__errorArgs = ['shipment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Take off Location</label>
                                <input type="text" class="form-control" id="inputFirstName" name="take_off"
                                    value="<?php echo e(old('take_off')); ?>">

                                <?php $__errorArgs = ['take_off'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Final Destination</label>
                                <input type="text" class="form-control" id="inputFirstName" name="final_destination"
                                    value="<?php echo e(old('final_destination')); ?>">

                                <?php $__errorArgs = ['final_destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Date Shipped</label>
                                <input type="date" class="form-control " name="date_shipped"
                                    value="<?php echo e(old('date_shipped')); ?>" />

                                <?php $__errorArgs = ['date_shipped'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Time Shipped</label>
                                <input type="text" class="form-control timepicker" name="time_shipped"
                                    value="<?php echo e(old('time_shipped')); ?>" />

                                <?php $__errorArgs = ['time_shipped'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Expected Delivery Date</label>
                                <input type="date" class="form-control" name="expected_delivery_date"
                                    value="<?php echo e(old('expected_delivery_date')); ?>" />

                                <?php $__errorArgs = ['expected_delivery_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Expected Delivery Time</label>
                                <input type="text" class="form-control timepicker" name="expected_delivery_time"
                                    value="<?php echo e(old('expected_delivery_time')); ?>" />

                                <?php $__errorArgs = ['expected_delivery_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Actual Delivery Date </label>
                                <input type="date" class="form-control " name="actual_delivery_date"
                                    value="<?php echo e(old('actual_delivery_date')); ?>" />

                                <?php $__errorArgs = ['actual_delivery_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Actual Delivery Time</label>
                                <input type="text" class="form-control timepicker" name="actual_delivery_time"
                                    value="<?php echo e(old('actual_delivery_time')); ?>" />

                                <?php $__errorArgs = ['actual_delivery_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            

                            <div class="card-title d-flex align-items-center mt-5">
                                <div><i class="bx bxs-user me-1 font-22 text-primary mt-3"></i>
                                </div>
                                <h5 class="mb-0 text-primary mt-3">Shipment Travel History</h5>
                            </div>
                            <span><a href="https://www.latlong.net/" class="text-danger " target="_blank">Click here</a>
                                to generate location <strong>Latitude</strong> and <strong>Longitude</strong>
                            </span>
                            <hr>

                            <div class="col-md-12">
                                <label for="inputFirstName" class="form-label">Shipment Location </label>
                                <input type="text" class="form-control" id="inputFirstName"
                                    name="travel_history_location" value="<?php echo e(old('travel_history_location')); ?>">

                                <?php $__errorArgs = ['travel_history_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Latitude </label>
                                <input type="text" class="form-control" id="inputFirstName" name="latitude"
                                    value="<?php echo e(old('latitude')); ?>">
                            </div>

                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Longitude </label>
                                <input type="text" class="form-control" id="inputFirstName" name="longitude"
                                    value="<?php echo e(old('longitude')); ?>">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Activity Date</label>
                                <input type="text" class="form-control" name="travel_history_date"
                                    value="<?php echo e(old('travel_history_date')); ?>" />

                                <?php $__errorArgs = ['travel_history_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Activity Time</label>
                                <input type="text" class="form-control timepicker" name="travel_history_time"
                                    value="<?php echo e(old('travel_history_time')); ?>" />

                                <?php $__errorArgs = ['travel_history_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <label for="inputAddress" class="form-label">Brief Description of Shipment</label>
                                <textarea class="form-control" id="inputAddress" placeholder="Brief description" rows="3"
                                    name="travel_history_description"><?php echo e(old('travel_history_description')); ?></textarea>

                                <?php $__errorArgs = ['travel_history_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <button type="submit" name="submit" class="btn btn-primary px-5">Create
                                    Shipment</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\PrimeTrustLogistics\resources\views/admin/tracking/create_tracking.blade.php ENDPATH**/ ?>