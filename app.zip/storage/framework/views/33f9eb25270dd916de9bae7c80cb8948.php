
<?php $__env->startSection('admin'); ?>
    <div class="page-content">
        <div class="row">
            <div class="col-12 mx-auto">
                <h6 class="mb-0 text-uppercase">Update Invoice</h6>
                <hr />

                <div class="card border-top border-0 border-4 border-primary">
                    <div class="card-body p-5">

                        <form action="<?php echo e(route('update.invoice')); ?>" method="POST" class="row g-3">
                            <?php echo csrf_field(); ?>

                            
                            <div class="card-title d-flex align-items-center">
                                <div><i class="bx bxs-user me-1 font-22 text-primary mt-3"></i>
                                </div>
                                <h5 class="mb-0 text-primary mt-3">Update Invoice information</h5>
                            </div>
                            <hr>

                            <input type="hidden" name="id" value="<?php echo e($invoice->id); ?>">

                            <div class="col-md-6">
                                <label class="form-label">Tracking No</label>
                                <input type="text" class="form-control" id="inputFirstName" name="tracking_id"
                                    value=" <?php echo e($invoice->tracking->tracking_no); ?> [<?php echo e($invoice->tracking->receiver_fullname); ?>]"
                                    readonly>
                            </div>

                            <div class="col-md-6">
                                <label for="inputFirstName" class="form-label">Bank Name</label>
                                <input type="text" class="form-control" id="inputFirstName" name="bank_name"
                                    placeholder="Enter bank name" value="<?php echo e($invoice->bank_name); ?>">

                                <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Account Number</label>
                                <input type="text" class="form-control" name="acct_no" placeholder="Enter account number"
                                    value="<?php echo e($invoice->acct_no); ?>" />

                                <?php $__errorArgs = ['acct_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Freight Amount</label>
                                <input type="number" class="form-control timepicker" name="frieght_amount"
                                    placeholder="Enter freight amount" value="<?php echo e($invoice->frieght_amount); ?>" />

                                <?php $__errorArgs = ['frieght_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Warehouse Fee</label>
                                <input type="number" class="form-control timepicker" name="warehouse_fee"
                                    placeholder="Enter warehouse fee" value="<?php echo e($invoice->warehouse_fee); ?>" />

                                <?php $__errorArgs = ['warehouse_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Custom Fee</label>
                                <input type="number" class="form-control timepicker" name="custom_fee"
                                    placeholder="Enter custom fee" value="<?php echo e($invoice->custom_fee); ?>" />

                                <?php $__errorArgs = ['custom_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <button type="submit" name="submit" class="btn btn-primary">Update Invoice</button>
                            </div>
                        </form>
                        <button onclick="window.history.back()" class="btn btn-danger mt-3">Back</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\PrimeTrustLogistics\resources\views/admin/invoice/edit_invoice.blade.php ENDPATH**/ ?>